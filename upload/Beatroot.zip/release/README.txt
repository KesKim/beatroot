Beatroot
========

Global Game Jam 2013 Finland / Tampere project

Olli Etuaho - Code Painter
Kimmo Keskinen - Code Wanker
Timo Koriseva - Code Thrower
Taaniel Teiss - Music Magician

======== INSTALLATION INSTRUCTIONS / HOW TO PLAY
Open index.html in browser.
Developed on Chrome 24: possible web browser incompatibility glitches with other browsers.

======== 3RD PARTY CODE
Uses third-party library html5slider by Frank Yan, https://github.com/fryn/html5slider